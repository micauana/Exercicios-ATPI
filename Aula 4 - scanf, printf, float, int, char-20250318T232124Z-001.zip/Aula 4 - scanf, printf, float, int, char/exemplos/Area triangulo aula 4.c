//Programa para calcular area do triangulo teste aula 4//
#include<stdio.h>
int main(){
float base, altura, area;
printf("Base: ");
scanf("%f",&base);
printf("Altura: ");
scanf("%f",&altura);
area = (base*altura)/2;
printf("Area: %f\n", area);
}
