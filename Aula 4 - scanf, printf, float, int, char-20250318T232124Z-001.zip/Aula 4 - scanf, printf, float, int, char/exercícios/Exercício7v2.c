//Exerc�cio 7 - aula 4 - tabuada, vers�o 2//
#include<stdio.h>
int main(){
int num;
printf("Forne�a um n�mero: ");
scanf("%d", &num);
printf("%dx0=%d\n%dx1=%d\n%dx2=%d\n%dx3=%d\n%dx4=%d\n%dx5=%d\n%dx6=%d\n%dx7=%d\n%dx8=%d\n%dx9=%d\n%dx10=%d\n", num,num*0,num,num*1,num,num*2,num,num*3,num,num*4,num,num*5,num,num*6,num,num*7,num,num*8,num,num*9,num,num*10);
return 0;
}
