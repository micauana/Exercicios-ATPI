//Exercício 1 - aula 4 - ler um número e o imrpimir//
#include <stdio.h>
int main(){
int num;
printf("Forneça um número:\n");
scanf("%d",&num);
printf("O número é: %d",num);
    return 0;
}