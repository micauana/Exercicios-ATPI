//Exercício 2 - aula 4 - ler um número real e o imrpimir//
#include<stdio.h>
int main(){
float num;
printf("Forneça um número: \n");
scanf("%f", &num);
printf("O número é: %f", num);
return 0;
}