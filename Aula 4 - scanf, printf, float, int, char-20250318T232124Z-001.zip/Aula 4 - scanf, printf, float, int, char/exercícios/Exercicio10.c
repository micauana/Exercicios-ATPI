//Exerc�cio 10 - aula 4 - Pr�mio para primeiro, segundo e terceiro colocados//
#include<stdio.h>
int main(){
int valor, primeiro, segundo, terceiro;
valor = 780000;
primeiro = 0.5*valor;
segundo = 0.3*valor;
terceiro = 0.20*valor;
printf("Primeiro lugar: %d\n", primeiro);
printf("Segundo lugar: %d\n", segundo);
printf("Terceiro lugar: %d\n", terceiro);
return 0;
}
