//Exercicio 7 - aula 4 - Tabuada de um n�mero inteiro//
#include<stdio.h>
int main(){
int num, tabuada0, tabuada1, tabuada2, tabuada3, tabuada4, tabuada5, tabuada6, tabuada7, tabuada8, tabuada9, tabuada10;
printf("Forne�a um n�mero: \n");
scanf("%d",&num);
tabuada0 = num*0;
tabuada1 = num*1;
tabuada2 = num*2;
tabuada3 = num*3;
tabuada4 = num*4;
tabuada5 = num*5;
tabuada6 = num*6;
tabuada7 = num*7;
tabuada8 = num*8;
tabuada9 = num*9;
tabuada10 = num*10;
printf("Tabuada: \n");
printf("%d\n", tabuada0);
printf("%d\n", tabuada1);
printf("%d\n", tabuada2);
printf("%d\n", tabuada3);
printf("%d\n", tabuada4);
printf("%d\n", tabuada5);
printf("%d\n", tabuada6);
printf("%d\n", tabuada7);
printf("%d\n", tabuada8);
printf("%d\n", tabuada9);
printf("%d\n", tabuada10);
return 0;
}
